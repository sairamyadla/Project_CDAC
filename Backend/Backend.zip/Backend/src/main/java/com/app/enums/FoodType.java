package com.app.enums;

public enum FoodType {
	
	VEG,NONVEG
}
