package com.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entities.Tiffin;

public interface TiffinRepository extends JpaRepository<Tiffin, Long> {

}
