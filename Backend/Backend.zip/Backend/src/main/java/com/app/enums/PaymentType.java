package com.app.enums;

public enum PaymentType {
	
	UPI,CARD,COD,NETBANKING
	
}
