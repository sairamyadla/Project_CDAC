package com.app.enums;

public enum PaymentStatus {
	
	PENDING,COMPLETED
	
}
