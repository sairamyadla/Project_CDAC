package com.app.enums;

public enum UserRole {
	
	ROLE_CUSTOMER,ROLE_VENDOR,ROLE_ADMIN
	
}
