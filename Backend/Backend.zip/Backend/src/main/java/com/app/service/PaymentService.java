package com.app.service;

import com.app.dto.PaymentDTO;

public interface PaymentService {

	PaymentDTO savePaymentDetails(PaymentDTO paymentDTO);

}
